<h1>WEB 200 Fundamentals of Web Development</h1>
<h2>Contributors</h2>
<ul>
    <li>Professor Soriano</li>
    <li>Ferdinand Detres Jr</li>
</ul>